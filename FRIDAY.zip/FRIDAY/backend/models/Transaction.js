const mongoose = require("mongoose");

const TransactionSchema = new mongoose.Schema({
  merchant: String,
  amount: Number,
  score: Number,
  decision: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Transaction", TransactionSchema);